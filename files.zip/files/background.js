// HETEC Sign Connector – Hintergrund-Script (Manifest V3 Service Worker)
//
// Bewusst NUR manueller Auslöser: automatische Erkennung jeder geladenen
// oder heruntergeladenen PDF wurde entfernt, weil sonst auch Rechnungen,
// Preislisten usw. ungefragt in HETEC Sign aufgemacht worden wären.
//
// Ablauf: Mitarbeiter hat eine Vertrags-PDF im aktiven Tab offen (egal ob
// Telekom/o2-Portal sie inline zeigt oder herunterlädt) und klickt bewusst
// auf das Symbolleisten-Icon. Erst dann wird die PDF über fetch() geholt
// (nutzt die bestehende Anmeldesitzung/Cookies) und an HETEC Sign
// übergeben - dort entscheidet die vorhandene Vertragserkennung wie gehabt,
// ob "Auf Tablet öffnen" angeboten wird.

const PWA_URL = 'https://hetec-it.github.io/HETEC-Sign/pc-app.html';

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.url) return;
  if (tab.url.indexOf(PWA_URL) === 0) return; // schon HETEC Sign geöffnet
  await handlePdf(tab.url, tab.id);
});

async function handlePdf(url, sourceTabId) {
  try {
    const resp = await fetchWithRetry(url, 3);
    const buffer = await resp.arrayBuffer();
    const base64 = arrayBufferToBase64(buffer);
    const filename = guessFilename(url);

    const tabId = await getTargetTab(sourceTabId);

    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: (b64, fname) => {
        if (window.__hetecSignIngestFile) window.__hetecSignIngestFile(b64, fname);
      },
      args: [base64, filename],
    });

    notify('PDF an HETEC Sign übergeben', filename);
  } catch (e) {
    console.error('HETEC Sign Connector Fehler:', e);
    notify('HETEC Sign Connector: Fehler', String(e && e.message ? e.message : e));
  }
}

// Mehrere Versuche, weil Portale wie thop.telekom.de gelegentlich mit einem
// Netzwerkfehler statt einer sauberen HTTP-Antwort reagieren.
async function fetchWithRetry(url, attempts) {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try {
      // WICHTIG: credentials:'include' schickt die bestehende Anmeldesitzung
      // (Cookies) mit - ohne das schlägt der Abruf bei Portalen, die eine
      // gültige Session voraussetzen, fehl (Standard-Verhalten von fetch()
      // bei domainübergreifenden Anfragen ist, KEINE Cookies zu senden).
      const resp = await fetch(url, { credentials: 'include' });
      if (resp.ok) return resp;
      lastErr = new Error('HTTP ' + resp.status);
    } catch (e) {
      lastErr = e;
    }
    if (i < attempts - 1) await new Promise((r) => setTimeout(r, 600));
  }
  throw lastErr;
}

// Baut den Quelltab (den Tab, in dem geklickt wurde) direkt zu HETEC Sign um,
// statt einen zusätzlichen Tab zu öffnen.
async function getTargetTab(sourceTabId) {
  if (sourceTabId != null) {
    try {
      await chrome.tabs.update(sourceTabId, { url: PWA_URL, active: true });
      await waitForTabComplete(sourceTabId);
      return sourceTabId;
    } catch (e) {
      // Quelltab existiert nicht mehr o.ä. - auf Suche/Neu-öffnen ausweichen
    }
  }
  const [existing] = await chrome.tabs.query({ url: PWA_URL + '*' });
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    return existing.id;
  }
  const created = await chrome.tabs.create({ url: PWA_URL, active: true });
  await waitForTabComplete(created.id);
  return created.id;
}

function waitForTabComplete(tabId) {
  return new Promise((resolve) => {
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(resolve, 8000); // Sicherheitsnetz, falls das Event mal ausbleibt
  });
}

function guessFilename(urlStr) {
  try {
    const u = new URL(urlStr);
    const nameParam = u.searchParams.get('NAME') || u.searchParams.get('name');
    if (nameParam) {
      const decoded = decodeURIComponent(nameParam);
      const parts = decoded.split('_');
      const last = parts[parts.length - 1];
      if (last) return last;
    }
    const lastSeg = u.pathname.split('/').pop();
    if (lastSeg && /\.pdf$/i.test(lastSeg)) return lastSeg;
  } catch (e) {}
  return 'vertrag.pdf';
}

function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function notify(title, message) {
  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon-128.png',
      title,
      message: message || '',
    });
  } catch (e) {}
}
