# HETEC Sign Connector – Installation (Edge/Chrome, ohne Adminrechte)

Bewusst rein manuell: die Extension tut nichts von selbst, sie wird nur
aktiv, wenn du auf ihr Symbol klickst. So läuft nicht bei jeder x-beliebigen
PDF (Rechnung, Preisliste, ...) automatisch HETEC Sign an.

## 1. Extension laden
1. Adresszeile: `edge://extensions` (Chrome: `chrome://extensions`) öffnen
2. Oben rechts **„Entwicklermodus"** aktivieren
3. **„Entpackt laden"** klicken
4. Den Ordner `hetec-sign-extension` auswählen (alle Dateien dieser Lieferung
   in einen Ordner legen, dann den Ordner auswählen – nicht einzelne Dateien)
5. Fertig – kein Neustart nötig, kein Adminrecht nötig (Entwicklermodus ist
   eine Einstellung pro Benutzerprofil)

Falls „Entpackt laden" ausgegraut ist: dann ist Entwicklermodus bei euch per
Firmenrichtlinie gesperrt – dann bräuchtet ihr doch IT-Unterstützung für
diesen einen Schritt.

## 2. Nutzung
1. Vertrags-PDF im Telekom-/o2-System öffnen (egal ob sie im Tab angezeigt
   oder heruntergeladen wird)
2. Auf das **HETEC-Sign-Connector-Icon** oben rechts in der Symbolleiste
   klicken
3. Der Tab baut sich zu HETEC Sign um, die PDF wird automatisch geprüft
4. Kurze Benachrichtigung „PDF an HETEC Sign übergeben" zur Bestätigung

Bei allen anderen PDFs (Rechnungen, Preislisten, Anleitungen) einfach nichts
klicken – die Extension rührt sich dann gar nicht.

## Bekannte Grenzen
- Läuft nur, solange die Extension aktiv ist (kein Werkskonto/Verteilung an
  alle Shops ohne IT – das wäre der nächste Schritt, falls gewünscht)
- Braucht `<all_urls>`-Berechtigung, weil unbekannt ist, welche Domain(s)
  das Telekom-/o2-Portal für den PDF-Download nutzt – deshalb nur auf
  firmeneigenen, vertrauenswürdigen Geräten installieren
